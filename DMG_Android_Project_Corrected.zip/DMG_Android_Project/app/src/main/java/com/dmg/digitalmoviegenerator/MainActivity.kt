package com.dmg.digitalmoviegenerator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF080D1A)
private val Panel = Color(0xFF151F35)
private val Cyan = Color(0xFF42D9FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DMGHome() }
    }
}

@Composable
fun DMGHome() {
    val tools = listOf(
        "Photo to Video", "Action Edit",
        "Object Change", "Spot / Location Change",
        "Prompt Editor", "Effects",
        "Music & Sound Effects", "Scene-by-Scene Movie Editor"
    )
    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Cyan
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Navy).padding(18.dp)
        ) {
            Text("DMG", color = Cyan, fontSize = 34.sp)
            Text("DIGITAL MOVIE GENERATOR", color = Color.White, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Text("Create your movie", color = Color.White, fontSize = 23.sp)
            Text("Choose a tool to get started", color = Color.LightGray)
            Spacer(Modifier.height(18.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(tools) { name ->
                    Card(
                        modifier = Modifier.fillMaxWidth().height(112.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Panel)
                    ) {
                        Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.Center) {
                            Text(name, color = Color.White, fontSize = 16.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Preview • Create Video • Export", color = Cyan, fontSize = 14.sp)
        }
    }
}
