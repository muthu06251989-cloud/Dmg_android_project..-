DMG - DIGITAL MOVIE GENERATOR
Corrected starter project folder.

IMPORTANT:
- This is Android source code, not an installable APK.
- It currently shows a starter home screen only.
- AI video generation, real object/location replacement, sound generation,
  export, and server-side generation limits are NOT connected yet.
- A compatible Android build environment is needed to create and test an APK.
- No payment, subscription, or credit-card feature is included in this starter.
